# CiMAC - UI Design

### Live applicaion URL

[Visit Here](https://www.astramind.io/)

#

### To start application local machine run the below commands -

#### 1. `yarn install`

#### 2. `yarn start`

#

### Packages & Libraries used to build the UI -

#### 1. react

#### 2. react-dom

#### 3. chakra-ui

#### 4. node-sass

#### 5. react-icons

#### 6. victory

#### 7. react-circular-progressbar

#
