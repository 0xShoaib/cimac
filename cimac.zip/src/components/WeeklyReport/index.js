import WeeklyReport from "./WeeklyReport";

export default WeeklyReport;
