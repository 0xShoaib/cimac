import UpdateMonitoring from "./UpdateMonitoring";

export default UpdateMonitoring;
